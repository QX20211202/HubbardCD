#!/bin/sh


for ((lCD=0; lCD<=2; lCD++))
do

echo $lCD

dir=lCD$lCD
if ! test -d $dir; then
    mkdir $dir
fi

cp HubbardCD $dir/.
cd $dir

cat > input << eof
&CONTROL

! Common model parameters
th = 1.0                 ! t-hopping
U  = 8.0                 ! U-interaction
Boundary = 0             ! [0,1,2] for [Open, PBC, APB]
Nsite = 6                ! # of sites
Nelec = 6                ! # of electrons
Nup   = 3                ! # of up spin
Ndn   = 3                ! # of down spin

! Common time evolution parameters
NTime    = 100           ! # of time steps
TimeZero = 0.0           ! Evolution start time
TimeOne  = 0.1           ! Evolution finish time
Tau      = 0.1           ! Period

! Common Chebyshev parameters
NCheby   = 5             ! Order of Chebyshev expansion
Eoff     = 0.01          ! Energy cutoff

! Common fidelity parameters
Fidelity_calc = T        ! calc fidelity or not

! Common spectrum parameters
Spectrum_calc = T        ! calc low-lying spectrum
Nev = 2                  ! # of eigenvalues

! Time Evolution Algorithm for [200 <= D <= 5000]
! Exact is always used for D < 200.
! Chebyshev is always used for D > 5000.
ALGO  = 1                ! 1 Cheby 2 Exact

! Renormalize time-evolved wave function
Renormalization = F

! CD parameters
lCD = $lCD                  ! 0 for UA, >0 for CD  -1 for FE
FT  = 1                  ! F1 or F2

! Continued calc
Restart_mode  =  0       ! 0 from scratch  1 continued 
Njump  =  0              ! write TE wave after Njump steps 

! Other parameters
Verbosity  =  0

/

See P. W. Claeys, et al., Phys. Rev. Lett. 123, 090602 (2019)
UA: Unassisted
CD: Counter Diabatic
FE: Floquet-Engineered

eof
./HubbardCD


cd ..




done












